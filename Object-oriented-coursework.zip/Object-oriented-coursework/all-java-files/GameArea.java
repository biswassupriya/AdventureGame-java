package com.adventure.game;

/**
 * interface GameArea
 */
public interface GameArea {
    boolean isFightRequired();
    boolean isPuzzleRequired();
    boolean isGamePlayRequired();
    boolean isContainSpecialItem();
}
