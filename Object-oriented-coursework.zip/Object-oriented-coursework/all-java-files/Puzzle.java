package com.adventure.game;

/**
 * interface Puzzle
 */
public interface Puzzle {
    boolean solvePuzzle(int number1, int number2, int product);
}
