package com.adventure.game;

/**
 * class MultiplicationPuzzle  implements the Puzzle class to
 * solve puzzle which have two integer varibale name maxAttempts with a value of three which means
 * the player will have maximum of three attempts to solve the puzzle and useattempts
 */
public class MultiplicationPuzzle implements Puzzle {

    private final int MAX_ATTEMPTS = 3;
    private int userAttempts = 0;

    /**
     * the method with a return type
     * @param number1
     * @param number2
     * @param product
     * @return boolean
     */
    @Override
    public boolean solvePuzzle(int number1, int number2, int product) {
        boolean solved = false;

        /**
         * if condition to solve the puzzle
         */
        if(userAttempts < MAX_ATTEMPTS) {
            if(multiply(number1, number2, product)){
                solved = true;
                System.out.println("Your Answer is Correct. Puzzle Solved Successfully");
                userAttempts = 0;
            } else {
                System.out.println("Your Answer is Wrong. Try the next puzzle");
                userAttempts++;
            }
        } else {
            System.out.println("You have finished your max attempts");
        }
        return solved;
    }

    /**
     * multiply method with return type boolean to get the product of two numbers
     */
    private boolean multiply(int number1, int number2, int product) {
        System.out.println("What is the product of " + number1 + " and " + number2);
        System.out.println("You replied " + product);
        return number1 * number2 == product;
    }
}
