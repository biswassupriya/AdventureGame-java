package com.adventure.game;

import java.util.Random;

public class Fight {

    /**
     *class variables name and values
     */
    private final Random rand = new Random();
    private final String[] enemies = {"Bones", "Snake", "Fighter", "Killer"};
    private final int maxHealthOfEnemy = 85;
    private final int damageOnEnemyAttack = 35;


    /**
     *player variables
     */
    private int health = 99;
    private final int damageDuringAttack = 60;
    private int potionsOFHealth = 4;
    int HealAmountOfHealthPotion = 40;
    private final int healthPotionChanceDrop = 40; //Percentage

    /**
     * method of return type
     */
     void fight() {
        int enemyHealth = rand.nextInt(maxHealthOfEnemy);
        String enemy = enemies[rand.nextInt(enemies.length)];
        System.out.println("\t#" + enemy + "appeared! #\n");

       /**
        * while loop
        */
        while (enemyHealth > 0) {
            System.out.println("\tYour HP:" + health);
            System.out.println("\t" + enemy + "HP:" + enemyHealth);


            int damageDealt = rand.nextInt(damageDuringAttack);
            int damageTaken = rand.nextInt(damageOnEnemyAttack);

            enemyHealth -= damageDealt;
            health -= damageTaken;

            System.out.println("\t> You hit the" + enemy + "for" + damageDealt + "damage.");
            System.out.println("\t> You receive" + damageTaken + "in revenge!");

            if (health < 1) {
                System.out.println("\t> You have afftected extra damage, you are too weak to play now!");
                break;
            }
        }
        System.out.println("###################################");
        System.out.println("#" + enemy + "was lost! #");
        System.out.println(" # You have" + health + "HP left. #");
        if (rand.nextInt(100) < healthPotionChanceDrop) {
            potionsOFHealth++;
            System.out.println(" # The" + enemy + "dropped a health potion! #");
            System.out.println(" # You now have " + potionsOFHealth + "health potion(s). #");
        }
        System.out.println("#########################################################");
    }

    /**
     * method with an integer return type
     * @return
     */
    public int getHealth() {
        return health;
    }

    /**
     * method with no return type
     * @param health
     */
    public void setHealth(int health) {
        this.health = health;
    }
}
