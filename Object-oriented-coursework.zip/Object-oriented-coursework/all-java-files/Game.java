package com.adventure.game;

/**
 * interface Game
 */
public interface Game {

    /**
     * method with boolean return type
     * @param number
     * @return
     */
    boolean playGame(int number);
}
