package com.adventure.game;

/**
*DiceRollling class extends AbstractGame to play Game where the dice will roll with
 * user attempts variable where the value is zero
*/
public class DiceRollingGame extends AbstractGame {

    private int userAttempts = 0;

    /**
     * The playGame method with boolean return type and the integer parameter
     */
    @Override
    public boolean playGame(int number) {
        boolean win = false;
        /**
         * using loop where the userattempts are less than the maximum attempts
         */
        if(userAttempts < MAX_ATTEMPTS) {
            if (rollDice(number)) {
                win = true;
                System.out.println("You win. .Game Over");
                userAttempts = 0;
            } else {
                System.out.println("Sorry you lost. Take another shot");
                userAttempts++;
            }
        } else {
            System.out.println("You have finished your max attempts");
        }
         return win;
    }

    /**
     *boolean method as a return type. The method name is rollDice with an integer number variables
     */
    private boolean rollDice(int number) {
        int mod = number % 2;
        System.out.println("Your dice roll returned " + number);
        if(mod == 0) {
            System.out.println("Computer dice roll returned " + number);
        } else {
            System.out.println("Computer dice roll returned " + number+1);
        }
        return mod == 0;
    }

}