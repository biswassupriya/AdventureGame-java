package com.adventure.game;

/**
 * Abstract class name as AbstractGame which implements the class Game with protected integer vaiable
 * as Maximum attaempts of three.
 */
public abstract class AbstractGame implements Game {

    protected final int MAX_ATTEMPTS = 3;
}
