package com.adventure.game;

/**
 * abstract class DefaultGameArea implements the interface GaneArea
 */
public abstract class DefaultGameArea implements GameArea {

    /**
     * method with return type as boolean to get the false result
     * @return
     */
    @Override
    public boolean isFightRequired() {
        return false;
    }

    @Override
    public boolean isPuzzleRequired() {
        return false;
    }

    @Override
    public boolean isGamePlayRequired() {
        return false;
    }

    @Override
    public boolean isContainSpecialItem() {
        return false;
    }
}
