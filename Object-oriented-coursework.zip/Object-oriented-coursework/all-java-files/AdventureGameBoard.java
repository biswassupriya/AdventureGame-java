package com.adventure.game;
/**
 * import arraylist and list from java util library
  */
import java.util.ArrayList;
import java.util.List;

/**
 * the class AdventureGameBoard has a variable of two arraylist with a object as board
 */
public class AdventureGameBoard {
    private GameArea[][] board = new GameArea[5][5];

    /**
     * constructor AdventureGameBoard used the for loop
     */
    public AdventureGameBoard() {
        for(int i=0; i<5; i++) {
            for(int j=0; j<5; j++) {
                if(i == 2 && j == 2) {
                    board[i][j] = new SpecialItemGameArea();
                } else if (i == 0 || i == 4) {
                    board[i][j] = new BattlefieldArea();
                } else if (i == 1 || i == 3) {
                    board[i][j] = new PlaygroundArea();
                } else if (i == 2) {
                    board[i][j] = new LibraryArea();
                }
            }
        }
    }

    /**
     * method with the return type as list with an oject for the list as bnusItems to get the array
     * lists for the play method with two integer parameter and a fight object to fight
     * @param areaX
     * @param areaY
     * @return
     */
    public List<BonusItems> play(int areaX, int areaY) {
        List<BonusItems> bonusItems = new ArrayList<>();
        Fight fight = new Fight();

        GameArea userArea = board[areaX][areaY];

        if(userArea.isContainSpecialItem()) {
            System.out.println("You got special Item");
            bonusItems.add(BonusItems.KEY);
            bonusItems.add(BonusItems.HEALTH_BOOSTER);
            bonusItems.add(BonusItems.SHIELD);
            bonusItems.add(BonusItems.WEAPON);
            bonusItems.add(BonusItems.SPECIAL_ITEM);
        }

        if(userArea.isFightRequired()) {
            fight.fight();
            bonusItems.add(BonusItems.WEAPON);
        }

        if(userArea.isPuzzleRequired()) {
            MultiplicationPuzzle puzzle = new MultiplicationPuzzle();
            boolean win = puzzle.solvePuzzle(2, 3, 6);
            if(win) {
                bonusItems.add(BonusItems.KEY);
            }
        }

        if(userArea.isGamePlayRequired()) {
            DiceRollingGame rolling = new DiceRollingGame();
            boolean win = rolling.playGame(4);
            if(win) {
                bonusItems.add(BonusItems.HEALTH_BOOSTER);
            }
        }

        if(bonusItems.contains(BonusItems.HEALTH_BOOSTER)) {
            fight.setHealth(fight.getHealth() + 1);
        }

        System.out.println("Final health = " + fight.getHealth());

        return bonusItems;
    }
}
