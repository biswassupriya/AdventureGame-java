package com.adventure.game;

/**
 * PlaygraoundArea class is the inheritace and extends the parent class DefaultGameArea
 */
public class PlaygroundArea extends DefaultGameArea {

    /**
     * method with return type
     * @return
     */
    @Override
    public boolean isGamePlayRequired() {
        return true;
    }
}
