package com.adventure.game;

/**
 * battlefieldArea class extends the DefaultGamearea which is the intehiritance of the parent class
 * DefaultGameArea
 */
public class BattlefieldArea extends DefaultGameArea {

    /**
     * isFightRequired method with boolean as the return type to get the true result
     * @return
     */
    @Override
    public boolean isFightRequired() {
        return true;
    }
}
