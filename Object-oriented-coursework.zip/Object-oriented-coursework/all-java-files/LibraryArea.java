package com.adventure.game;

/**
 * LibraryArea class which is the inheritance class extends the parents class DefaultGameArea
 */
public class LibraryArea extends DefaultGameArea {

    /**
     * method with a boolean return type
     * @return
     */
    @Override
    public boolean isPuzzleRequired() {
        return true;
    }
}
