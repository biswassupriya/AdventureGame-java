package com.adventure.game;

/**
 * SpecialItemGameArea class which extends the parent class DefaultGameArea
 */
public class SpecialItemGameArea extends DefaultGameArea {

    /**
     * method return type
     * @return
     */
    @Override
    public boolean isContainSpecialItem() {
        return true;
    }
}
