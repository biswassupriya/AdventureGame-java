package com.adventure.game;

/**
 * BonusItems method of return type enum for all the collections of the bonus items
 */
public enum BonusItems {
    KEY,
    SHIELD,
    WEAPON,
    HEALTH_BOOSTER,
    SPECIAL_ITEM
}
