package com.adventure.game;

/**
 * import arraylist and list from java util library
 */
import java.util.ArrayList;
import java.util.List;

/**
 * the class AdventureGameMain main class with an object as board to get the list of the
 * bonus items while playing
 */
public class AdventureGameMain {
    public static void main(String[] args) {
        AdventureGameBoard board = new AdventureGameBoard();

        List<BonusItems> bonusItems = board.play(2, 3);

        for(BonusItems item : bonusItems) {
            System.out.println("Bonus item received " + item);
        }
    }
}
