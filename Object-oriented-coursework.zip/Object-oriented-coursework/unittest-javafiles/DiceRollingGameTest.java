package com.adventure.game;

import org.junit.Test;

import static org.junit.Assert.*;

public class DiceRollingGameTest {

   @Test
    public void testPlayGame_GameCompletes(){
       DiceRollingGame rolling = new DiceRollingGame();
       boolean win = rolling.playGame(4);
       assertTrue(win);
    }

    @Test
    public void testPlayGame_GameCompletesAtFinalAttempt(){
        DiceRollingGame rolling = new DiceRollingGame();
        rolling.playGame(1);
        rolling.playGame(3);
        boolean win = rolling.playGame(4);
        assertTrue(win);
    }

    @Test
    public void testPlayGame_MaximumAttemptExhausted(){
        DiceRollingGame rolling = new DiceRollingGame();
        rolling.playGame(1);
        rolling.playGame(3);
        rolling.playGame(5);
        boolean win = rolling.playGame(4);
        assertFalse(win);
    }
}