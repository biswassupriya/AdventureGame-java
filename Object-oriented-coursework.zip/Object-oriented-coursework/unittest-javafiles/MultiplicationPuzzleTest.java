package com.adventure.game;

import org.junit.Test;

import static org.junit.Assert.*;

public class MultiplicationPuzzleTest {


    @Test
    public void testplayPuzzle_PuzzleComplete(){
        MultiplicationPuzzle puzzle = new MultiplicationPuzzle();
        boolean puzzleResult = puzzle.solvePuzzle(2, 3, 6);
        assertTrue(puzzleResult);
    }

    @Test
    public void testplayPuzzle_SolvedAtFinalAttempt(){
        MultiplicationPuzzle puzzle = new MultiplicationPuzzle();
        puzzle.solvePuzzle(2, 3, 7);
        puzzle.solvePuzzle(2, 3, 5);
        boolean puzzleResult = puzzle.solvePuzzle(2, 3, 6);
        assertTrue(puzzleResult);
    }

    @Test
    public void testilyPuzzle_MaxAttemptExhausted(){
        MultiplicationPuzzle puzzle = new MultiplicationPuzzle();
        puzzle.solvePuzzle(2, 3, 7);
        puzzle.solvePuzzle(2, 3, 5);
        puzzle.solvePuzzle(2, 3, 4);
        boolean puzzleResult = puzzle.solvePuzzle(2, 3, 6);
        assertFalse(puzzleResult);
    }

}