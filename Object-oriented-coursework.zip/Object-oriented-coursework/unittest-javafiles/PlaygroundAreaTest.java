package com.adventure.game;

import org.junit.Test;

import static org.junit.Assert.*;

public class PlaygroundAreaTest {

    @Test
    public void isGamePlayRequired() {
        PlaygroundArea playgroundArea = new PlaygroundArea();
        assertTrue(playgroundArea.isGamePlayRequired());
    }
}