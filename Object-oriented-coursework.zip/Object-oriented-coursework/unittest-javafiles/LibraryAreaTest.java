package com.adventure.game;

import org.junit.Test;

import static org.junit.Assert.*;

public class LibraryAreaTest {

    @Test
    public void isPuzzleRequired() {
        LibraryArea libraryArea = new LibraryArea();
        assertTrue(libraryArea.isPuzzleRequired());
    }
}