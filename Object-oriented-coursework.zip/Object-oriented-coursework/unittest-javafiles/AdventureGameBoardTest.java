package com.adventure.game;

import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class AdventureGameBoardTest {

    @Test
    public void play_SpecialItem() {
        AdventureGameBoard board = new AdventureGameBoard();
        List<BonusItems> bonusItems = board.play(2,2);
        assertTrue(bonusItems.contains(BonusItems.SPECIAL_ITEM));
    }

    @Test
    public void play_LibraryArea() {
        AdventureGameBoard board = new AdventureGameBoard();
        List<BonusItems> bonusItems = board.play(2,1);
        assertTrue(bonusItems.contains(BonusItems.KEY));
    }

    @Test
    public void play_DefaultGameArea() {
        AdventureGameBoard board = new AdventureGameBoard();
        List<BonusItems> bonusItems = board.play(1,3);
        assertTrue(bonusItems.contains(BonusItems.HEALTH_BOOSTER));
    }

    @Test
    public void play_BattlefieldArea() {
        AdventureGameBoard board = new AdventureGameBoard();
        List<BonusItems> bonusItems = board.play(0,2);
        assertTrue(bonusItems.contains(BonusItems.WEAPON));
        assertFalse(bonusItems.contains(BonusItems.SPECIAL_ITEM));
    }
}