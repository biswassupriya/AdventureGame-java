package com.adventure.game;

import org.junit.Test;

import static org.junit.Assert.*;

public class BattlefieldAreaTest {

    @Test
    public void isFightRequired() {
        BattlefieldArea battlefieldArea = new BattlefieldArea();
        assertTrue(battlefieldArea.isFightRequired());
        assertFalse(battlefieldArea.isContainSpecialItem());
    }
}